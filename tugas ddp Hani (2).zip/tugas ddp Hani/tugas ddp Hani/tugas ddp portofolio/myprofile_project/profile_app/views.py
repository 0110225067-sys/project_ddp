from django.shortcuts import render

def home(request):
    context = {
        'name': 'Hani Septiani',
        'title': 'Mahasiswi',
        'email': 'hseptiani259@gmail.com',
        'phone': '+62 822-7124-5344',
        'location': 'Medan, Indonesia',
        'description': 'Saya adalah mahasiswa jurusan Teknik Informatika yang memiliki minat besar pada dunia teknologi dan pengembangan sistem informasi. Saya tertarik mempelajari pemrograman, pengolahan data, serta pemanfaatan teknologi digital untuk menyelesaikan berbagai permasalahan. Melalui jurusan ini, saya terus mengembangkan kemampuan berpikir logis, analitis, dan kreatif, baik secara mandiri maupun melalui kerja tim. Saya juga terbuka untuk mempelajari teknologi baru dan berkomitmen untuk meningkatkan keterampilan agar dapat berkontribusi secara positif di bidang teknologi informasi di masa depan.✨.',
        'social_links': {
            'github': 'https://github.com/0110225067-sys',
        }
    }
    return render(request, 'profile_app/home.html', context)

def about(request):
    context = {
        'education': [
            {
                'degree': 'SD',
                'institution': 'SDN 0401 Pasar Ujung Batu',
                'year': '2012 - 2018',
                'description': ''
            },
            {
                'degree': 'MTSN',
                'institution': 'MTSN 1 Padang Lawas',
                'year': '2019 - 2022',
                'description': ''
            },
            {
                'degree': 'SMA ',
                'institution': 'SMA Negeri 1 Barunmun',
                'year': '2022 - 2025',
                'description': 'Osis Pendidikan.'
            },
            {
                'degree': 'Mahasiswa Teknik Informatika',
                'institution': 'STT Nurul Fikri',
                'year': '2025 - Sekarang',
                'description': ''
            }
            
        ],
        'organizations': [
            {
                'role': 'Pendidikan',
                'organization': 'Osis SMA Negeri 1 Barunmun',
                'period': '2024-2025',
                'description': 'Saya pernah menjadi anggota Osis SMA Negeri 1 Barunmun.'
            }
        ]
    }
    return render(request, 'profile_app/about.html', context)

def gallery(request):
    context = {
        'gallery_items': [
            {
                'title': 'Panitia Classmeet',
                'description': 'Panitia Classmeet SMA Negeri 1 Barunmun',
                'image': 'images/panitia.jpg',
                'date': '2024-2025'
            },
            {
                'title': 'Lomba Oliempade Kimia',
                'description': 'Mengikuti Lomba Oliempade Kimia Tingkat Provinsi Sumatra Utara',
                'image': 'images/kimia.jpg',
                'date': '2025'
            },
            {
                'title': 'Lomba Oliempade Biologi',
                'description': 'Lomba Biologi Tingkat Provinsi Sumatra Utara',
                'image': 'images/biologi.jpg',
                'date': '2025'
            },
           
        ]
    }
    return render(request, 'profile_app/gallery.html', context)